sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, Filter, FilterOperator) {
        "use strict";

        return Controller.extend("exam.exprogram05.controller.Main", {
            onInit: function () {
                this.getView().setModel(new JSONModel({
                    lProd: [{
                        CategoryID: "",
                        ProductName: "",
                        UnitsInStock: "",
                        UnitsOnOrder: ""
                    }]
                }), 'Prod');
                this.getView().setModel(new JSONModel({
                    lSbyC: [{
                        ProductName: "",
                        ProductSales: "",
                    }]
                }), 'SbyC');
            },
            onSearch: function () {
                var sCateID = this.getView().byId("idInput").getValue();
                var sCateName = this.getView().byId("cateInput").getValue();

                var aFilter = [];
                if (sCateID) aFilter.push(new Filter('CategoryID', 'GE', sCateID));
                if (sCateName) aFilter.push(new Filter('CategoryName', 'Contains', sCateName));

                this.getView().byId("idTableSearch").getBinding("items").filter(new Filter({
                    filters: aFilter,
                    and: true
                }));
            },
            fnColorFormat: function () {

            },
            formatIcon: function (UnitsInStock) {
                if (UnitsInStock) {
                    var oFilter = new Filter("UnitsOnOrder", 'GT', UnitsInStock);
                    var oModel = this.getView().getModel();

                    oModel.read("/Products", {
                        filters: [oFilter],
                        success: function (oData) {
                            var oProduct = oData.results[0];
                            if (oProduct.UnitsInStock > oProduct.UnitsOnOrder) {
                                return 'sap-icon://circle-task';
                            } else {
                                return 'sap-icon://decline';
                            }
                        }.bind(this),
                        error: function (oError) {
                        }
                    });
                }
            },
            onSelectionChange: function (oEvent) {

                var sCategoryID = oEvent.getParameter("listItem").getBindingContext().getProperty("CategoryID");

                if (sCategoryID) {

                    var oFilter = new Filter("CategoryID", 'EQ', sCategoryID);
                    var oModel = this.getView().getModel();
                    var sModel = this.getView().getModel('Prod');
                    var yModel = this.getView().getModel('SbyC');
                    var oTable = this.byId("idTablePro");
                    var oViz = this.byId("idDataset");

                    oModel.read("/Products", {
                        filters: [oFilter],
                        success: function (oData) {
                            sModel.setData({ lProd: oData.results }, true);
                            oTable.getBinding("rows").filter([oFilter]);

                        },
                        error: function (oError) {
                        }
                    });

                    oModel.read("/Sales_by_Categories", {
                        filters: [oFilter],
                        success: function (oData) {
                            yModel.setData({ lSbyC: oData.results }, true);
                            oViz.getBinding("data").filter([oFilter]);
                        },
                        error: function (oError) {
                        }
                    });


                }
            },
            onSelectionChangeViz: function (oEvent) {
                var PNdata = oEvent.getParameters().data[0].data.ProductName;
                var PSdata = oEvent.getParameters().data[0].data.ProductSales;
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo('RouteDetail', {
                    ProductName: PNdata,
                    ProductSales: PSdata
                });
            }
        });
    });
