sap.ui.define([
	"exam/exprogram_05/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
